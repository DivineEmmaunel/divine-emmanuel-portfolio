DIVINE EMMANUEL — PORTFOLIO WEBSITE

Static website built with HTML, CSS and JavaScript. No build step or package
installation is required.

FILES
- index.html: Main page and portfolio content
- style.css: Responsive styling for desktop, tablet and mobile
- script.js: Mobile navigation and automatic footer year

PUBLISH WITH GITHUB PAGES
1. Create a public GitHub repository, for example divine-emmanuel-portfolio.
2. Upload index.html, style.css and script.js directly into the repository root.
3. Open repository Settings > Pages.
4. Under Build and deployment, select "Deploy from a branch".
5. Choose the main branch and /(root), then Save.
6. Wait for publishing. GitHub displays your website URL in Settings > Pages.

PROJECTS
- Trivia Game: https://divineemmaunel.github.io/Trivia-Game/
- Medicure: https://divineemmaunel.github.io/Medicure/
- GitHub profile: https://github.com/divineemmaunel

The contact button links to your GitHub profile because no public email address
or LinkedIn profile URL has been provided. Add those details later if desired.
Review the project descriptions and skills before sharing publicly.
